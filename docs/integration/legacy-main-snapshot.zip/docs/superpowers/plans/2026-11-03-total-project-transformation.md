# Plan：御舆项目彻底改造执行路线

对应规格：docs/superpowers/specs/2026-11-03-total-project-transformation.md

执行纪律：

- 每个阶段先补契约测试，再迁移实现。
- 每个 PR 只承担一种主要风险：数据迁移、行为重构、视觉改造或文件搬家。
- 正文改写与构建器核心重构分开。
- 所有删除先证明可重建，并保留迁移标签或清单。
- 当前未提交的 R4 改动不纳入本计划的任何平台 PR。

## P0：冻结基线与收口在途工作

- [x] P0.1 完成或独立保存当前 R4 衍生物料改动，保证平台改造从干净提交开始。
- [x] P0.2 生成 baseline.json：单元、章节、标题、锚点、术语、来源、图版、插画、HTML 体积、PDF 页数。
- [x] P0.3 保存 20 个关键 HTML 片段和 12 张关键页截图，覆盖封面、目录、正文、宽表、横版图、索引和暗色窄屏。
- [x] P0.4 建立 video 文件身份清单：source、config、review、generated、cache、third_party。
- [x] P0.5 建立 legacy 标签，记录最后一版旧构建器和视频目录。
- [x] Gate：现有 Fast 检查通过；完整依赖环境下 make check 通过；基线文件可重复生成（PR #6 → 06bd6fb）。

## P1：环境、依赖与统一 CLI

- [x] P1.1 新增 pyproject.toml，登记 Python 3.12、包元数据、测试和工具配置。
- [x] P1.2 引入 Python 锁文件；requirements.txt 改为从锁定环境导出或与锁文件一致性校验。
- [x] P1.3 实现 bookctl doctor，检查 Python、Node、浏览器、字体、依赖、路径和写权限。
- [x] P1.4 实现 bookctl check --fast，统一通用测试、构建器测试、内容检查和 Mermaid 检查。
- [x] P1.5 Makefile 改为跨平台薄包装，clean 不再依赖 rm -rf。
- [x] P1.6 CI 使用与本地相同的 bookctl 命令。
- [x] Gate：全新环境的缺依赖错误在 doctor 中一次列全；Windows/Ubuntu 命令一致（PR #7 → 4155de9）。

## P2：Schema、稳定 ID 与数据迁移

- [x] P2.1 为 manifest、glosses、sources、notes、reading-paths、revisions、subject-index 定义 schema_version。
- [x] P2.2 建立 BookModel 基础类型和统一 Diagnostic。
- [x] P2.3 设计 block_id 语法与 Markdown 承载方式，先在 ch01、ch03、ch12 三章试点。
- [x] P2.4 编写 line-ref → block-ref 迁移器，输出自动映射、歧义、缺失三类报告。
- [x] P2.5 双读所有登记表，比较 line-ref 与 block-ref 指向文本是否一致。
- [x] P2.6 全量迁移 20 个单元，加入“任意插入 50 行仍通过”的回归测试。
- [x] P2.7 停止新增行号证据；shift_anchors.py 标记为迁移期工具。
- [x] Gate：所有旧证据映射完成，歧义项为 0；正文插行不触发登记表 diff。

## P3：构建内核模块化

- [x] P3.1 将 build.py 的 CLI、应用服务和产品装配拆开。
- [x] P3.2 拆 core.py：I/O、路径、配置、模型、诊断。
- [x] P3.3 拆 render.py：Markdown、HTML 变换、引用、图版、长名称。
- [x] P3.4 拆 pages.py：前置页、正文单元、后置页、导航。
- [x] P3.5 拆 style.py：令牌、屏幕、打印、组件、装饰 SVG；构建时合并内联。
      `style_tokens.py` / `style_screen.py` / `style_components.py` / `style_print.py`；
      `style_css.py` 只做聚合，CSS sha256 `fa65c59f…` 与拆分前一致。
- [x] P3.6 定义 PrintManifest，让 PDF 后处理读取结构化元数据。
- [x] P3.7 每完成一个模块，运行 legacy/v2 双构建并比较结构报告。
      `scripts/compare_legacy.py` + `docs/baseline/legacy-v2-deltas.json`；
      报告 `docs/migrations/legacy-v2-structure.md`：2026-11-07 同内容双内核结构差异 0；
      对 P0 的 93 项差异命中既有规则，但来源门禁仍失败，不等于整体 Gate 已绿。
- [x] P3.8 新内核成为默认后，保留旧入口一个阶段并输出弃用提示。
      `yuyu-book/build.py` 直接调用时提示改用 `scripts/bookctl.py build`；
      `bookctl` 以 `YUYU_BOOKCTL=1` 调用旧入口，不重复提示。
- [ ] Gate：结构等价报告全绿；HTML 离线、无脚本、PDF 契约全部保持。
      2026-11-07 实测：冻结 1,071 份相同内容输入，HEAD `dcdc395` 与当前内核双语构建成功；
      PDF 中文 525 页 / 英文 577 页、各 28 书签，逐页文本和链接目标一致；离线禁脚本导航通过。
      **阻塞**：Fast 通用测试 126 passed / 1 failed，既有白名单 21 条来源不是提交 SHA；
      另有四条精确值规则与固定测试的 `delta` 要求待审。本轮未改白名单、测试、runner 或 CI；
      P3 Gate 保持未勾，不提前进入 P6。构建器单测另跑 541 passed；详见上述比较报告。

## P4：产品生成器统一

- [x] P4.1 建立共享设计令牌和组件语义，覆盖大书、portal、reader、gallery、cards、sample。
      `products/tokens.py` 是唯一色板（30 色）与字体/圆角来源；`tests/test_product_tokens.py`
      扫描全部 9 个生成页，任何未登记颜色即失败。
- [x] P4.2 beginner reader 从读取 dist HTML 改为读取 BookModel。
- [x] P4.3 illustration gallery、site portal、知识卡和样章改为产品适配器。
      `products/{gallery,portal,cards,sample}.py`；`scripts/build_*.py` 仅保留入口；
      样章复用同管线渲染的第 2 章正文（含 mermaid 图版），其余帧体走令牌。
- [x] P4.4 生成静态双语搜索索引、同段语言跳转表和概念关联表。
      `products/indices.py` → `docs/search-index.json`（6,445 段）、
      `docs/language-map.json`（20 单元逐节对齐）、`docs/concept-map.json`（102 术语）；
      两版结构漂移时构建失败，`tests/test_site_indices.py` 守住新鲜度与关系计数。
- [x] P4.5 增加站点键盘、读屏、窄屏、暗色和 reduced-motion 测试。
      `tests/test_site_accessibility.py`（12 项契约，覆盖 9 个生成页：语言/视口/标题、
      单一 h1 与 header/main/footer、标题层级、`:focus-visible`、控件可聚焦可命名、
      图片替代文本、显式 color-scheme 与暗色媒体查询配对、reduce 块、画廊自动播放守卫、
      固定画幅 max-width、回站链接）；`tests/test_beginner_reader.py` 新增站点静态
      上一站/下一站导航测试；两份入门分册的站间导航改为构建期静态生成（原内联脚本
      语法错误且会破坏 flex 布局）；320px 移动视口浏览器核验 portal/reader/gallery/
      cards/sample 均无页面级横向滚动；大书样式表补 `svg *{animation:none!important}`
      使样章的 mermaid 图版遵守 reduced-motion。
- [x] P4.6 对三个现有生成页执行统一视觉审计，保留御舆墨线体系。
      报告 `docs/migrations/product-visual-audit.md`：portal / 两份入门分册 / 画廊的
      纸色、墨色、朱砂、切角、阴影、焦点环逐项测量，1280 与 320 视口、亮/暗偏好、
      reduce 静置态截图核验；修复英文分册丢失的 `.st-navrow` / `.prog` 规则、
      续读条误留的「站」字，并为两份分册页脚补回 `portal.html` 链接；
      三处修复各配契约测试。
- [x] Gate：所有产品重跑无 diff；关闭脚本仍可完整阅读和导航。
      六个生成器二次运行后 11 个产物 SHA-256 全部不变；portal 零脚本，
      分册三个渐进脚本、25 组上一站/下一站为静态标记，画廊图版与题注静态。

## P5：事实与双语治理

- [x] P5.1 建立 Claim Ledger schema 和 claim_id 规则。
      `yuyu_book/claims.py`：`claims.json` 登记进 `registry.FILES`；id 为小写 slug、
      全局唯一；`kind`/`risk`/`status` 为封闭集合；中英各一份 `{unit, block, quote}`
      定位符共享同一个 `claim_id`；`value` 必须同时出现在两侧引文里。
- [x] P5.2 导入版本、价格、数量、默认行为、性能数据和功能标志等高风险断言。
      六个种子 claim 覆盖全部六种 kind（version `2.1.310`、default `Manual`、
      count `55`、price `$3.00`、performance `72%`、flag `PROACTIVE`），
      来源、`verified`、`review_days` 齐备；`tests/test_claims.py` 17 项。
- [x] P5.3 中英文段落共享 claim_id，增加单边更新失败测试。
      `test_one_edition_updated_without_the_other`：只改一侧引文里的值时验证失败；
      `test_both_editions_must_anchor_the_same_unit`、`test_every_active_claim_pairs_both_editions`
      守住配对。
- [x] P5.4 增加复查周期、过期告警和发布阻断级别。
      高风险过期在 CI（`release=False`）只告警，正式发布（`release=True`）报错阻断；
      普通风险只告警；`retired` 不再追正文也不再过期。
- [x] P5.5 为 15 章补齐最小可运行案例、练习、预期结果和版本锁。
      双语 30 个代码围栏，首行 `# exercise: chNN`，`# expected:` 给出逐行输出；
      每章有最小可运行案例、版本锁（Python 3.12 标准库）、预期结果、前置与回链；
      `tests/test_exercises.py` 4 项：执行 15 段代码并比对输出、两版代码逐字相同、
      标签齐全、章章恰有一例。
- [x] P5.6 把事实、推断、教学简化和作者建议的标记规则写入 CONTRIBUTING.md。
      §5.3 Claim Ledger 写法与 §5.4 四类标记（事实/推断：/为讲解起见/建议：），
      §8 清单新增两条。
- [x] Gate：正式发布模拟中，过期高风险 claim 为 0；双语事实差异为 0。
      `release=True`、`today=2026-11-06` 跑六个 active claim：告警 0、值缺失 0。

## P6：视频工厂重建

- [ ] P6.1 根级固定唯一 HyperFrames 版本，建立 video/pipeline/。
- [ ] P6.2 定义 episode schema、scene schema、voice/caption manifest。
- [ ] P6.3 抽出长版、短版、字幕、封面和音频检查的共享步骤。
- [ ] P6.4 迁移 ch01，完成旧新时间线、字幕、时长和关键帧比较。
- [ ] P6.5 迁移 ch02–ch05，删除章节级重复构建脚本和 package.json。
- [ ] P6.6 证明 transcript、chunks、vo-manifest、字幕 HTML、音频切片可重建后停止跟踪。
- [ ] P6.7 用统一内容包扩展 ch06–ch15。
- [ ] P6.8 增加字幕一致性、安全区、字号、停留时间、闪烁、响度和版权门禁。
- [ ] Gate：15 章配置可检查；ch01–ch05 完成兼容审阅；中间物不进入 Git。

## P7：CI 与发布系统

- [ ] P7.1 抽取公共环境准备 workflow/composite action。
- [ ] P7.2 建立 Fast、Full、Release 三层任务和路径过滤。
- [ ] P7.3 缓存 Python、npm、Playwright、Mermaid 和字体资源。
- [ ] P7.4 每次构建输出 build-report.json 与 artifact-manifest.json。
- [ ] P7.5 Release 生成双语 HTML/PDF、站点包、视频清单、SHA-256 和版本说明。
- [ ] P7.6 增加生成器幂等、关键页视觉回归、链接和重定向检查。
- [ ] P7.7 合并或删除重复 workflow，README 徽章与真实门禁一致。
- [ ] Gate：PR 只跑必要层；主分支与发布层稳定；产物能追溯到 commit 和依赖。

## P8：清理、文档与正式切换

- [ ] P8.1 删除旧 line-ref 写入、旧构建入口和失效兼容层。
- [ ] P8.2 清理 video/ 中已证明可重建的中间物和重复配置。
- [ ] P8.3 更新 STRUCTURE.md、CONTRIBUTING.md、README.md、en/README.md。
- [ ] P8.4 增加架构决策记录：稳定 ID、BookModel、PDF 边界、站点脚本边界、视频资产策略。
- [ ] P8.5 从干净 clone 完成 Windows 与 Ubuntu 双平台演练。
- [ ] P8.6 发布首个新架构版本并保留 legacy 标签与迁移说明。
- [ ] Gate：规格第 7 节全部验收；旧路径无调用者；正式发布产物可下载、可校验。

## 建议 PR 切片

| PR | 范围 | 主要风险 |
|---|---|---|
| 1 | P0 基线与视频身份清单 | 无行为变化 |
| 2 | pyproject、锁文件、doctor | 环境 |
| 3 | bookctl check 与 CI 对齐 | 工具入口 |
| 4 | Schema + BookModel 骨架 | 数据读取 |
| 5 | 三章稳定 ID 试点 | 证据绑定 |
| 6 | 全量稳定 ID 迁移 | 数据迁移 |
| 7–9 | 构建器按 core/render/style-pages 拆分 | 输出等价 |
| 10 | PDF PrintManifest | 分页与书签 |
| 11–12 | reader/gallery/portal/cards 统一 | 产品输出 |
| 13 | Claim Ledger | 内容治理 |
| 14–16 | 视频 ch01、ch02–05、ch06–15 | 媒体迁移 |
| 17 | CI 三层与发布清单 | 发布 |
| 18 | 删除兼容层与文档收官 | 清理 |

## 每个 PR 的完成定义

- [ ] Spec 对应条目有测试或可复核证据。
- [ ] 通用测试、构建器测试、内容检查、Mermaid 检查通过。
- [ ] 涉及输出时，生成器连续运行两次无 diff。
- [ ] 涉及双语内容时，中英文同批更新。
- [ ] 涉及视觉或 PDF 时，附关键页比较。
- [ ] 涉及删除时，附可重建证明和删除清单。
- [ ] 不提交 dist、缓存、中间媒体或第三方工具副本。
- [ ] 更新相关结构文档，不在修订账本中写无法重算的数字。

## 推荐执行顺序

先完成 P0–P2，消除环境和行号锚点这两个会放大后续改动成本的问题；随后执行 P3–P4，建立统一内核和产品适配器；再做 P5 内容治理与 P6 视频工厂；最后用 P7–P8 收拢 CI、发布和旧代码。P2 未完成前不开始大规模正文扩写，P3 未稳定前不做全站视觉换骨，P6 不与 PDF 内核迁移并行。


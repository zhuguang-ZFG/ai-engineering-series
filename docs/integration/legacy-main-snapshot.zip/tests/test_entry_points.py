"""P3.8: bookctl is the default entry; direct build.py is on notice."""
import contextlib
import io
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "yuyu-book"))
sys.path.insert(0, str(ROOT / "scripts"))

import build  # noqa: E402
import bookctl  # noqa: E402


class TransitionalEntry(unittest.TestCase):
    def notice(self) -> str:
        buf = io.StringIO()
        with contextlib.redirect_stderr(buf):
            build.warn_transitional_entry()
        return buf.getvalue()

    def set_marker(self, value: str | None) -> None:
        old = os.environ.get("YUYU_BOOKCTL")
        if value is None:
            os.environ.pop("YUYU_BOOKCTL", None)
        else:
            os.environ["YUYU_BOOKCTL"] = value

        def restore():
            if old is None:
                os.environ.pop("YUYU_BOOKCTL", None)
            else:
                os.environ["YUYU_BOOKCTL"] = old
        self.addCleanup(restore)

    def test_direct_invocation_points_at_bookctl(self):
        self.set_marker(None)
        text = self.notice()
        self.assertIn("transitional entry", text)
        self.assertIn("scripts/bookctl.py build", text)

    def test_bookctl_calls_stay_silent(self):
        self.set_marker("1")
        self.assertEqual(self.notice(), "")


class BookctlMarksItsCalls(unittest.TestCase):
    def test_run_sets_the_marker_in_the_child_environment(self):
        seen = {}
        original = bookctl.subprocess.run

        def fake(cmd, cwd, check, env):
            seen.update(cmd=cmd, env=env)
        bookctl.subprocess.run = fake
        self.addCleanup(setattr, bookctl.subprocess, "run", original)
        with contextlib.redirect_stdout(io.StringIO()):
            bookctl.run(["true"])
        self.assertEqual(seen["env"].get("YUYU_BOOKCTL"), "1")


if __name__ == "__main__":
    unittest.main()
